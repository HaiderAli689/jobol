class ImageConstant {
  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgFrame = 'assets/images/img_frame.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgArrowleftGray900 =
      'assets/images/img_arrowleft_gray_900.svg';

  static String imgFrameOnprimarycontainer =
      'assets/images/img_frame_onprimarycontainer.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgLockPink300 = 'assets/images/img_lock_pink_300.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
